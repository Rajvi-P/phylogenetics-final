.. _ABySS: http://www.bcgsc.ca/platform/bioinfo/software/abyss
.. _Amazon Web Services: http://aws.amazon.com/
.. _amplicon sequencing: http://www.ncbi.nlm.nih.gov/pubmed/18274529
.. _anaconda: http://docs.continuum.io/anaconda/install.html
.. _BAM: https://samtools.github.io/hts-specs/SAMv1.pdf
.. _bartab: http://www.phyloware.com/Phyloware/XSTK.html
.. _bcl2fastq: https://support.illumina.com/downloads/bcl2fastq_conversion_software_184.ilmn
.. _BED: https://genome.ucsc.edu/FAQ/FAQformat.html#format1
.. _bedtools: http://bedtools.readthedocs.io/en/latest/
.. _bioconda: https://bioconda.github.io/
.. _bwa: http://bio-bwa.sourceforge.net/
.. _Casava: http://support.illumina.com/sequencing/sequencing_software/casava.ilmn
.. _CC-BY: http://creativecommons.org/licenses/by/4.0/
.. _cli branch: https://github.com/faircloth-lab/phyluce/tree/cli
.. _CLI: http://en.wikipedia.org/wiki/Command-line_interface
.. _CloudForest: https://github.com/ngcrawford/CloudForest
.. _conda-forge: https://conda-forge.org/
.. _conda: http://docs.continuum.io/conda/
.. _exabayes: http://sco.h-its.org/exelixis/web/software/examl/index.html
.. _examl: http://sco.h-its.org/exelixis/web/software/exabayes/index.html
.. _FastQC: http://www.bioinformatics.babraham.ac.uk/projects/fastqc/
.. _fastx-toolkit: http://hannonlab.cshl.edu/fastx_toolkit/
.. _gblocks: http://molevol.cmima.csic.es/castresana/Gblocks.html
.. _github: https://github.com/faircloth-lab/phyluce
.. _gzip: http://www.gzip.org/
.. _HiSeq: http://www.illumina.com/systems/hiseq_2500_1500.ilmn
.. _homebrew: http://mxcl.github.com/homebrew/
.. _IDTDNA: http://www.idtdna.com/site
.. _Illumina: http://www.illumina.com/
.. _illumiprocessor: https://github.com/faircloth-lab/illumiprocessor/
.. _Kent Source Archive: http://hgdownload.soe.ucsc.edu/admin/exe/
.. _lastz: http://www.bx.psu.edu/~rsharris/lastz/
.. _mafft: http://mafft.cbrc.jp/alignment/software/
.. _miniconda: https://conda.io/miniconda.html
.. _MiSeq: http://www.illumina.com/systems/miseq.ilmn
.. _multiprocessing: http://docs.python.org/2/library/multiprocessing.html
.. _muscle: http://www.drive5.com/muscle/
.. _NCBI: http://www.ncbi.nlm.nih.gov/
.. _Phylogenomics: http://en.wikipedia.org/wiki/Phylogenomics
.. _phyluce: https://github.com/faircloth-lab/phyluce
.. _Python: http://www.python.org
.. _RAD-seq: http://en.wikipedia.org/wiki/Restriction_site_associated_DNA_markers
.. _raxml: https://github.com/amkozlov/raxml-ng
.. _relational database: http://en.wikipedia.org/wiki/Relational_database
.. _RNA-seq: http://en.wikipedia.org/wiki/RNA-Seq
.. _SAM: https://samtools.github.io/hts-specs/SAMv1.pdf
.. _samtools: http://www.htslib.org/
.. _screen: http://www.gnu.org/software/screen/
.. _sqlite-tutorial: http://www.sqlite.org/sqlite.html
.. _sqlite: http://www.sqlite.org
.. _stampy: http://www.well.ox.ac.uk/project-stampy
.. _symlink: http://en.wikipedia.org/wiki/Symbolic_link
.. _symlinks: http://en.wikipedia.org/wiki/Symbolic_link
.. _tmux: http://tmux.sourceforge.net/
.. _Tree of Life: http://en.wikipedia.org/wiki/Tree_of_Life
.. _trimal: http://trimal.cgenomics.org
.. _Trinity: http://trinityrnaseq.sourceforge.net/
.. _uce-probe-sets: https://github.com/faircloth-lab/uce-probe-sets
.. _UCSC Genome Browser Downloads: https://genome.ucsc.edu/downloads
.. _UCSC Genome Browser: https://genome.ucsc.edu/
.. _unittests: http://en.wikipedia.org/wiki/Unit_testing
.. _velvet: http://www.ebi.ac.uk/~zerbino/velvet/
.. _virtualenv: http://www.virtualenv.org/
.. _docker: https://www.docker.com
.. _singularity: https://sylabs.io
.. _spades: https://cab.spbu.ru/software/spades/
.. _IQTree: http://www.iqtree.org
.. _pargenes: https://github.com/BenoitMorel/ParGenes
.. _Paup: https://www.google.com/search?client=safari&rls=en&q=paup&ie=UTF-8&oe=UTF-8
.. _Snakemake: https://snakemake.readthedocs.io/en/stable/ 