.. include:: ../global.rst
.. |date| date:: %d %B %Y %H:%M %Z (%z)

.. _Daily Use:

Phyluce in Daily Use
====================

.. toctree::
    :maxdepth: 1

    daily-use-1-quality-control
    daily-use-2-assembly
    daily-use-3-uce-processing
    daily-use-4-workflows
    list-of-programs
