.. include:: global.rst

Acknowledgements
================

We thank the following people, each of whom made contributions ensuring the
success of our work.  These include:

* Claire Mancuso
* Brant Peterson
* Brent Pederson
* Chris Moran
* Ken Jones
* Joe DeYoung
* LSU Genomics Facility
* UCLA Neuroscience Genomics Core
* M. Reasel
