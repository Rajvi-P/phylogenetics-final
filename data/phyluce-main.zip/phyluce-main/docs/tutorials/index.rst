.. include:: ../global.rst
.. |date| date:: %d %B %Y %H:%M %Z (%z)

Phyluce Tutorials
=================

.. toctree::
    :maxdepth: 1

   tutorial-1
   tutorial-2
   tutorial-3
   tutorial-4